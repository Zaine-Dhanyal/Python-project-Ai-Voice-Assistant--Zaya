import speech_recognition as sr
import pyttsx3
import datetime
import wikipedia
import webbrowser
import requests
import cv2
import tkinter as tk
from tkinter import scrolledtext
import threading
import urllib.parse
import pywhatkit
import random 
from datetime import datetime
import random
import smtplib
from email.message import EmailMessage
engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)
stop_listening = False 
API_KEY = "3981e65a46295c1a931e04c894ad7a95" 
speech_queue = [] 
def speak(text):
    """Convert text to speech"""
    print(f"Zaya: {text}")
    engine.say(text)
    engine.runAndWait()
    chat_area.insert(tk.END, f"Zaya: {text}\n")
    chat_area.yview(tk.END)
def wishMe():
    """Greets the user based on the time of day"""
    hour = datetime.now().hour 
    if 0 <= hour < 12:
        speak("Hello, Good Morning")
    elif 12 <= hour < 18:
        speak("Hello, Good Afternoon")
    else:
        speak("Hello, Good Evening")
def takeCommand():
    """Captures voice input and returns it as text"""
    global stop_listening
    if stop_listening:
        return "exit"
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.adjust_for_ambient_noise(source)
        audio = r.listen(source)
        try:
            statement = r.recognize_google(audio, language='en-in')
            print(f"User said: {statement}\n")
            chat_area.insert(tk.END, f"You: {statement}\n")
            chat_area.yview(tk.END)
            return statement.lower()
        except sr.UnknownValueError:
            print("I didn't catch that, please say it again.")
            return "None"
        except sr.RequestError:
            print("Sorry, I can't reach Google services right now.")
            return "None"
def set_reminder():
    """Set a simple reminder"""
    speak("What should I remind you about?")
    reminder_text = takeCommand()
    print(f"Captured Reminder: {reminder_text}") 
    if reminder_text and reminder_text != "None":
        with open("reminders.txt", "a") as file:
            file.write(reminder_text + "\n")
        speak(f"Reminder: '{reminder_text}' has been successfully saved.")
    else:
        speak("I couldn't understand the reminder.")
def fetch_movie_recommendation():
    """Fetches a random movie recommendation from a predefined list"""
    movie_list = ["Inception", "The Shawshank Redemption", "Interstellar", "The Dark Knight", "Forrest Gump", "Parasite", "The Matrix", "Titanic", "Avatar", "Joker"]
    movie = random.choice(movie_list)
    speak(f"I recommend you to watch {movie}")
def process_command():
    """Process the command from the user"""
    global stop_listening
    statement = takeCommand()
    if statement in ["good bye", "ok bye", "stop", "exit", "stop listening"]:
        speak("Your personal assistant Zaya is shutting down. Goodbye!")
        stop_listening = True
        root.quit()
    elif 'wikipedia' in statement:
        try:
            speak('Searching Wikipedia...')
            statement = statement.replace("wikipedia", "")
            if statement.strip():
                results = wikipedia.summary(statement, sentences=2)
                speak("According to Wikipedia")
                print(results)
                speak(results)
            else:
                speak("Please provide more details for the Wikipedia search.")
        except wikipedia.exceptions.DisambiguationError:
            speak("There are multiple results. Please specify more clearly.")
        except wikipedia.exceptions.PageError:
            speak("Sorry, no Wikipedia page found for that.")
        except wikipedia.exceptions.WikipediaException as e:
            speak(f"An error occurred while searching Wikipedia: {str(e)}")
    elif 'open youtube' in statement:
        webbrowser.open("https://www.youtube.com")
        speak("Opening YouTube")
    elif 'play' in statement:
        song = statement.replace("play", "").replace("on youtube", "").strip()
        if song:
            speak(f"Playing {song} on YouTube")
            pywhatkit.playonyt(song)
        else:
            speak("Please specify a song name.")
    elif 'open google' in statement:
        webbrowser.open("https://www.google.com")
        speak("Opening Google")
    elif 'open gmail' in statement:
        webbrowser.open("https://mail.google.com")
        speak("Opening Gmail")
    elif "weather" in statement:
        speak("Which city?")
        city_name = takeCommand()
        while city_name == "None" or not city_name.strip():
            print("I didn't catch that. Please say the city name again.")
            city_name = takeCommand()
        base_url = "https://api.openweathermap.org/data/2.5/weather?"
        complete_url = f"{base_url}appid={API_KEY}&q={city_name}&units=metric"
        try:
            response = requests.get(complete_url)
            weather_data = response.json()
            if weather_data.get("cod") == 200:
                temp = weather_data["main"]["temp"]
                description = weather_data["weather"][0]["description"]
                speak(f"The temperature in {city_name} is {temp}°C with {description}.")
            else:
                speak("City not found. Please try again.")
        except requests.exceptions.RequestException:
            speak("Sorry, I can't fetch the weather information right now.")
    elif 'time' in statement:
        strTime = datetime.now().strftime("%H:%M:%S")
        speak(f"The time is {strTime}")
    elif "who made you" in statement:
        speak("I was built by Zainab.")
    elif 'news' in statement:
        webbrowser.open("https://arynews.tv")
        speak("Here are some headlines from ARY News.")
    elif "camera" in statement or "take a photo" in statement:
        cam = cv2.VideoCapture(0)
        ret, frame = cam.read()
        if ret:
            cv2.imwrite("photo.jpg", frame)
            speak("Photo taken successfully")
        cam.release()
    elif 'search' in statement:
        statement = statement.replace("search", "")
        webbrowser.open(f"https://www.google.com/search?q={statement}")
        speak(f"Searching for {statement}")
    elif "tell me a fun fact" in statement:
        fun_facts = ["Bananas are berries, but strawberries are not!", "Honey never spoils.", "Octopuses have three hearts."]
        speak(random.choice(fun_facts))
    elif "set a reminder" in statement:
        set_reminder()
    elif "fetch a movie recommendation" in statement:
        fetch_movie_recommendation()
    elif "what is your name" in statement: 
        speak("I am Zaya, your personal assistant.")   
    elif "tell me a joke" in statement:
        jokes = [
        "Why don't scientists trust atoms? Because they make up everything!",
        "Why did the computer go to the doctor? Because it had a virus!",
        "Why can't you trust an atom? Because they make up everything!",
        "Why did the math book look sad? Because it had too many problems!" ]
        speak(random.choice(jokes))
    elif "how are you" in statement:
        speak("I am just a program, but I'm feeling great! How about you?")
    elif "flip a coin" in statement:
        outcome = random.choice(["Heads", "Tails"])
        speak(f"The coin landed on {outcome}!")
    elif "roll a dice" in statement:
        dice_roll = random.randint(1, 6)
        speak(f"You rolled a {dice_roll}!")
    elif "random number" in statement:
        random_num = random.randint(1, 100)
        speak(f"Your random number is {random_num}!")
    elif "give me a compliment" in statement:
        compliments = ["You are amazing!", "You have a great smile!", "You're a genius!"]
        speak(random.choice(compliments))
def start_listening():
    """Start listening for commands in a separate thread"""
    while not stop_listening:
        process_command()
# Create GUI
root = tk.Tk()
root.title("Zaya - Your AI Assistant")
root.geometry("400x500")
root.configure(bg="#F5F5DC")  
chat_area = scrolledtext.ScrolledText(root, wrap=tk.WORD, bg="white", fg="black", font=("Arial", 10))
chat_area.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)
button_frame = tk.Frame(root, bg="#F5F5DC")
button_frame.pack(pady=20)
start_button = tk.Button(button_frame, text="Start Listening", command=lambda: threading.Thread(target=start_listening).start(), width=20, height=2, bg="#D3D3D3", fg="black")
start_button.pack()
wishMe()  
root.mainloop()
